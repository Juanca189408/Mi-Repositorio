﻿using System.Data.Entity;
using TareaPOO.Clases;

public class BibliotecaContext : DbContext
{
    public DbSet<Libro> Libros { get; set; }
    public DbSet<Usuario> Usuarios { get; set; }
    public DbSet<Prestamo> Prestamos { get; set; }

    public BibliotecaContext() : base("name=BibliotecaDBConnectionString") { }
}
