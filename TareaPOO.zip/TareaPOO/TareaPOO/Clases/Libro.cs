﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TareaPOO.Clases
{
    public class Libro : Publicacion, IPrestable
    {
        public int NumeroPaginas { get; set; }

        public override void MostrarInformacion()
        {
            MessageBox.Show($"Título: {Titulo}, Autor: {Autor}, ISBN: {ISBN}, Año: {AnioPublicacion}, Páginas: {NumeroPaginas}");
        }

        public void Prestar() { /* Implementar lógica de préstamo */ }
        public void Devolver() { /* Implementar lógica de devolución */ }
    }

    public class Revista : Publicacion
    {
        public int NumeroVolumenes { get; set; }

        public override void MostrarInformacion()
        {
            MessageBox.Show($"Título: {Titulo}, Autor: {Autor}, ISBN: {ISBN}, Año: {AnioPublicacion}, Volúmenes: {NumeroVolumenes}");
        }
    }

    public class DVD : Publicacion
    {
        public TimeSpan Duracion { get; set; }

        public override void MostrarInformacion()
        {
            MessageBox.Show($"Título: {Titulo}, Autor: {Autor}, ISBN: {ISBN}, Año: {AnioPublicacion}, Duración: {Duracion}");
        }
    }

}
