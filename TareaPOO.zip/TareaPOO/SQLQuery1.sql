CREATE database Tarea3

Use tarea3


CREATE TABLE Libros (
    ISBN VARCHAR(13) PRIMARY KEY,
    Titulo VARCHAR(255),
    Autor VARCHAR(255),
    A�oPublicacion INT,
    NumeroPaginas INT
);


CREATE TABLE Usuarios (
    NumeroSocio VARCHAR(10) PRIMARY KEY,
    Nombre VARCHAR(255),
    Apellido VARCHAR(255)
);


CREATE TABLE Prestamos (
    ID INT IDENTITY PRIMARY KEY,
    ISBN VARCHAR(13),
    NumeroSocio VARCHAR(10),
    FechaPrestamo DATE,
    FechaDevolucion DATE NULL,
    FOREIGN KEY (ISBN) REFERENCES Libros(ISBN),
    FOREIGN KEY (NumeroSocio) REFERENCES Usuarios(NumeroSocio)
);
