Create Database GestionBiblioteca

Use GestionBiblioteca

CREATE TABLE Libros (
    ISBN VARCHAR(13) PRIMARY KEY,
    Titulo NVARCHAR(255),
    Autor NVARCHAR(255),
    AnoPublicacion INT,
    NumeroPaginas INT
);

CREATE TABLE Usuarios (
    NumeroSocio VARCHAR(10) PRIMARY KEY,
    Nombre NVARCHAR(255),
    Apellido NVARCHAR(255)
);

CREATE TABLE Prestamos (
    PrestamoID INT IDENTITY(1,1) PRIMARY KEY,
    ISBN_Libro VARCHAR(13),
    NumeroSocio_Usuario VARCHAR(10),
    FechaPrestamo DATETIME,
    FechaDevolucion DATETIME,
    FOREIGN KEY (ISBN_Libro) REFERENCES Libros(ISBN),
    FOREIGN KEY (NumeroSocio_Usuario) REFERENCES Usuarios(NumeroSocio)
);
